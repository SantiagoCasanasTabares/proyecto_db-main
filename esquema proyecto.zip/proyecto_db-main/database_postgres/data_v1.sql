\c mande_db

INSERT INTO  usuario(nombre_usuario, password) VALUES ('trolololol@gmail.com', '1234');
INSERT INTO  usuario(nombre_usuario, password) VALUES ('azulgrana@gmail.com', 'x123');
INSERT INTO  usuario(nombre_usuario, password, premium) VALUES ('tyler.durden@gmail.com', 'asdfd', TRUE);